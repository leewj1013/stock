from __future__ import annotations

import os
from importlib.util import find_spec

from .app import configured_stocks, latest_naver_trading_day, load_env, write_error_log
from .daily_check import task_error_status


def yes(value: bool) -> str:
    return "ok" if value else "missing"


def enabled(name: str, default: str = "0") -> str:
    return "on" if os.environ.get(name, default) == "1" else "off"


def dashboard_ready() -> str:
    try:
        os.makedirs("reports", exist_ok=True)
        return yes(find_spec("stock_alarm.dashboard") is not None and os.path.isdir("reports"))
    except OSError:
        return "missing"


def lines() -> list[str]:
    load_env()
    data_source = os.environ.get("DATA_SOURCE", "naver")
    stocks = configured_stocks()
    result = [
        f"DATA_SOURCE={data_source}",
        f"NOTIFIER={os.environ.get('NOTIFIER', 'telegram')}",
        f"watchlist_count={len(stocks)}",
        f"TELEGRAM_BOT_TOKEN={yes(bool(os.environ.get('TELEGRAM_BOT_TOKEN')))}",
        f"TELEGRAM_CHAT_ID={yes(bool(os.environ.get('TELEGRAM_CHAT_ID')))}",
        f"TELEGRAM_SEND_READY={yes(bool(os.environ.get('TELEGRAM_BOT_TOKEN') and os.environ.get('TELEGRAM_CHAT_ID')))}",
        f"AUTO_TRACK_PICKS={enabled('AUTO_TRACK_PICKS', '1')}",
        f"SEND_EMPTY_SELL_ALERT={enabled('SEND_EMPTY_SELL_ALERT')}",
        f"SELL_LOSS_PCT={os.environ.get('SELL_LOSS_PCT', '5')}",
        f"SELL_DROP_PCT={os.environ.get('SELL_DROP_PCT', '3')}",
        f"SELL_PROTECT_PROFIT_PCT={os.environ.get('SELL_PROTECT_PROFIT_PCT', '5')}",
        f"SELL_GIVEBACK_PCT={os.environ.get('SELL_GIVEBACK_PCT', '4')}",
        f"SELL_ATR_MULTIPLIER={os.environ.get('SELL_ATR_MULTIPLIER', '2')}",
        f"SELL_TIME_STOP_DAYS={os.environ.get('SELL_TIME_STOP_DAYS', '10')}",
        f"SELL_TIME_STOP_MIN_RETURN_PCT={os.environ.get('SELL_TIME_STOP_MIN_RETURN_PCT', '0')}",
        f"TAKE_PROFIT_1_PCT={os.environ.get('TAKE_PROFIT_1_PCT', '10')}",
        f"TAKE_PROFIT_1_SELL_RATIO={os.environ.get('TAKE_PROFIT_1_SELL_RATIO', '50')}",
        f"TAKE_PROFIT_2_PCT={os.environ.get('TAKE_PROFIT_2_PCT', '20')}",
        f"EXECUTION_COST_BPS={os.environ.get('EXECUTION_COST_BPS', '30')}",
        f"PERFORMANCE_MIN_SAMPLES={os.environ.get('PERFORMANCE_MIN_SAMPLES', '20')}",
        f"LEARNING_MIN_SAMPLES={os.environ.get('LEARNING_MIN_SAMPLES', '300')}",
        f"LEARNING_VALIDATION_MIN_SAMPLES={os.environ.get('LEARNING_VALIDATION_MIN_SAMPLES', '60')}",
        f"LEARNING_VALIDATION_FOLDS={os.environ.get('LEARNING_VALIDATION_FOLDS', '3')}",
        f"LEARNING_SIGNIFICANCE_LEVEL={os.environ.get('LEARNING_SIGNIFICANCE_LEVEL', '0.05')}",
        f"MAX_ENTRY_DAY_CHANGE_PCT={os.environ.get('MAX_ENTRY_DAY_CHANGE_PCT', '5')}",
        f"MAX_MA20_DISTANCE_PCT={os.environ.get('MAX_MA20_DISTANCE_PCT', '10')}",
        f"MAX_MA20_DISTANCE_ATR={os.environ.get('MAX_MA20_DISTANCE_ATR', '1.5')}",
        f"MIN_MARKET_UP_RATIO={os.environ.get('MIN_MARKET_UP_RATIO', '0.25')}",
        f"KRX_API_KEY={yes(bool(os.environ.get('KRX_API_KEY')))}",
        f"DYNAMIC_SCREENING_TOP_N={os.environ.get('DYNAMIC_SCREENING_TOP_N', '0')}",
        f"NEWS_LOOKUP={enabled('NEWS_LOOKUP')}",
        f"NEWS_SCORE_WEIGHT={os.environ.get('NEWS_SCORE_WEIGHT', '0')}",
        f"MIN_RECOMMEND_SCORE={os.environ.get('MIN_RECOMMEND_SCORE', '0')}",
        f"DART_LOOKUP={enabled('DART_LOOKUP')}",
        f"DART_API_KEY={yes(bool(os.environ.get('DART_API_KEY')))}",
        f"DART_SCORE_WEIGHT={os.environ.get('DART_SCORE_WEIGHT', '0')}",
        f"TOSS_CLIENT_ID={yes(bool(os.environ.get('TOSS_CLIENT_ID')))}",
        f"TOSS_CLIENT_SECRET={yes(bool(os.environ.get('TOSS_CLIENT_SECRET')))}",
        f"TOSS_TRADING_ENABLED={enabled('TOSS_TRADING_ENABLED')}",
        f"FUNDAMENTAL_LOOKUP={enabled('FUNDAMENTAL_LOOKUP')}",
        task_error_status(),
        f"dashboard_ready={dashboard_ready()}",
        f"recommendations_log={yes(os.path.exists('logs/recommendations.csv'))}",
        f"errors_log={yes(os.path.exists('logs/errors.log'))}",
    ]
    if data_source.lower() == "naver":
        try:
            result.append(f"latest_naver_trading_day={latest_naver_trading_day().isoformat()}")
        except Exception as error:
            result.append(f"latest_naver_trading_day=unavailable ({type(error).__name__})")
    return result


def main() -> None:
    try:
        print("\n".join(lines()))
    except Exception as error:
        write_error_log(error)
        raise


if __name__ == "__main__":
    main()
