from __future__ import annotations

import json
import hmac
import html
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

from .app import effective_exposure_limit_pct, latest_naver_trading_day, load_env, naver_rows, write_error_log
from .dashboard import latest_position_rows, render, today_recommendation_rows
from .data_store import active_strategy_version, import_legacy_virtual_trader, latest_portfolio_risk, recent_equity_trend, recent_position_checks, recent_price_quality, recent_virtual_sales, virtual_buy, virtual_deposit, virtual_trader_state
from .market_breadth import CACHE_PATH as MARKET_BREADTH_CACHE_PATH
from .sector_reference import load_sector_mapping
from .trading_profiles import PROFILES
from .us_dashboard import render_us


def profile_db_path(name: str) -> str:
    return PROFILES.get(name, PROFILES["aggressive"])["db_path"]


HOST = "127.0.0.1"
PORT = int(os.environ.get("DASHBOARD_PORT", "8765"))
# Only this port is ever handed to the Cloudflare tunnel (see start_remote_dashboard.ps1).
# It must never be able to reach the full dashboard, /remote-setup, or any POST route:
# a tunnel forwards every request to 127.0.0.1 regardless of the caller's real address, so
# an HTTP Host header (or client_address) can never tell a genuine local visit apart from
# one relayed through the tunnel. Keeping the write/admin routes on a separate port that is
# never tunneled is what actually enforces "local-only", not a header check.
REMOTE_PORT = int(os.environ.get("DASHBOARD_REMOTE_PORT", "8766"))
REMOTE_ORIGIN = os.environ.get("DASHBOARD_REMOTE_ORIGIN", "https://leewj1013.github.io").rstrip("/")


def allowed_local_origin(origin: str) -> bool:
    port = int(os.environ.get("DASHBOARD_PORT", str(PORT)))
    return origin.rstrip("/") in {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}


def allowed_origin(origin: str) -> str:
    clean = origin.rstrip("/")
    configured = os.environ.get("DASHBOARD_REMOTE_ORIGIN", REMOTE_ORIGIN).rstrip("/")
    if clean == configured or clean.startswith("http://127.0.0.1:") or clean.startswith("http://localhost:"):
        return clean
    return ""


def valid_remote_token(authorization: str) -> bool:
    expected = os.environ.get("DASHBOARD_REMOTE_TOKEN", "")
    supplied = authorization.removeprefix("Bearer ").strip() if authorization.startswith("Bearer ") else ""
    return bool(expected and supplied and hmac.compare_digest(expected, supplied))


def recommendations() -> list[dict[str, str]]:
    return today_recommendation_rows()


def prices(path: str = "data/stock_alarm.db") -> dict[str, int]:
    price_map = {
        row.get("ticker", ""): int(float(row.get("close") or 0))
        for row in recommendations()
        if row.get("ticker") and row.get("close")
    }
    # A position report is newer than the original recommendation price.
    price_map.update({
        row.get("ticker", ""): int(float(row.get("close") or 0))
        for row in latest_position_rows()
        if row.get("ticker") and row.get("close")
    })
    holding_tickers = [row["ticker"] for row in virtual_trader_state(path=path)["holdings"]]
    today = date.today()

    def fetch(ticker: str) -> tuple[str, list] | None:
        try:
            return ticker, naver_rows(ticker, today - timedelta(days=10), today, max_cache_age_seconds=60)
        except (OSError, ValueError, TypeError):
            # Keep the most recent report/recommendation price if Naver is temporarily unavailable.
            return None

    with ThreadPoolExecutor(max_workers=max(len(holding_tickers), 1)) as pool:
        for result in pool.map(fetch, holding_tickers):
            if result and result[1]:
                price_map[result[0]] = int(result[1][-1][4])
    return price_map


def trader_payload(profile: str = "aggressive") -> dict:
    path = profile_db_path(profile)
    state = virtual_trader_state(prices(path), path=path)
    holding_tickers = {str(row.get("ticker") or "") for row in state["holdings"]}
    try:
        sectors = load_sector_mapping(holding_tickers)
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        sectors = {}
    risk = latest_portfolio_risk(path)
    strategy = active_strategy_version()
    quality = recent_price_quality(100, path)
    latest_quality = {}
    for row in quality:
        latest_quality.setdefault(row.get("ticker"), row)
    unavailable = [row["ticker"] for row in state["holdings"] if latest_quality.get(row["ticker"], {}).get("status") not in {None, "valid"}]
    breadth = None
    try:
        with open(MARKET_BREADTH_CACHE_PATH, encoding="utf-8") as file:
            snapshot = json.load(file)
            if snapshot.get("as_of_date") == date.today().isoformat():
                breadth = float(snapshot.get("up_ratio"))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass
    profile_config = PROFILES.get(profile, PROFILES["aggressive"])
    market_limit = effective_exposure_limit_pct(breadth, profile_config["exposure_limit_pct"]) if breadth is not None else None
    market_mode = "공격" if breadth is not None and breadth >= .60 else "중립" if breadth is not None and breadth >= .45 else "방어" if breadth is not None else "데이터 대기"
    from .toss_client import BLOCKING_STOCK_WARNINGS, TossClient
    latest_checks = {}
    for row in recent_position_checks(1000, path):
        latest_checks.setdefault(row.get("ticker"), row)
    holding_ticker_list = [str(holding.get("ticker") or "") for holding in state["holdings"]]

    def fetch_warnings(ticker: str) -> set[str]:
        try:
            return {row["warningType"] for row in toss_client.stock_warnings(ticker)}
        except Exception:
            return set()

    try:
        toss_client = TossClient()
        toss_client.access_token()  # prime the token cache before fanning out concurrently
    except Exception:
        toss_client = None
    if toss_client is None:
        warnings_by_ticker = dict.fromkeys(holding_ticker_list, set())
    else:
        with ThreadPoolExecutor(max_workers=max(len(holding_ticker_list), 1)) as pool:
            warnings_by_ticker = dict(zip(holding_ticker_list, pool.map(fetch_warnings, holding_ticker_list)))

    for holding in state["holdings"]:
        check = latest_checks.get(holding.get("ticker"), {})
        try:
            fallback_holding_days = (date.today() - date.fromisoformat(str(holding.get("first_entry_at") or "")[:10])).days
        except ValueError:
            fallback_holding_days = None
        stop_pct = float(check.get("dynamic_stop_loss_pct") or -5)
        stop_price = round(float(holding.get("average_price") or 0) * (1 + stop_pct / 100))
        distance = check.get("distance_ma20_pct")
        active_warnings = warnings_by_ticker.get(str(holding.get("ticker") or ""), set())
        blocking = active_warnings & BLOCKING_STOCK_WARNINGS
        non_blocking = active_warnings - BLOCKING_STOCK_WARNINGS
        if blocking:
            watch_state = f"종목 경고: {','.join(sorted(blocking))}"
        elif holding.get("position_status") == "partial":
            watch_state = "1차 익절 완료"
        elif check.get("decision") == "SELL":
            watch_state = "매도조건 충족"
        elif check.get("return_pct") is not None and float(check["return_pct"]) <= stop_pct * .8:
            watch_state = "손절선 근접"
        elif distance is not None and float(distance) <= 2:
            watch_state = "20일선 주의"
        elif non_blocking:
            watch_state = f"종목 주의: {','.join(sorted(non_blocking))}"
        else:
            watch_state = "정상 보유"
        holding.update({
            "sector": sectors.get(str(holding.get("ticker") or ""), "미분류"),
            "allocation_pct": round(float(holding.get("valuation") or 0) / max(float(state.get("total_equity") or 0), 1) * 100, 2),
            "holding_days": check.get("holding_days") if check.get("holding_days") is not None else fallback_holding_days,
            "watch_state": watch_state,
            "stop_price": stop_price,
            "ma20": check.get("ma20"),
        })
    try:
        from .screener import fundamentals_for
        fundamentals = fundamentals_for(holding_ticker_list)
    except Exception:
        fundamentals = {}
    for holding in state["holdings"]:
        holding.update(fundamentals.get(str(holding.get("ticker") or ""), {}))
    sales = []
    for row in recent_virtual_sales(500, path):
        cost_basis = int(row.get("cost_basis") or 0)
        realized = int(row.get("realized_profit_loss") or 0)
        sales.append({
            **row,
            "return_pct": round(realized / cost_basis * 100, 2) if cost_basis else 0.0,
            "sale_label": "부분매도" if row.get("sale_type") == "partial" else "전량매도",
        })
    wins = sum(int(row.get("realized_profit_loss") or 0) > 0 for row in sales)
    total_cost = sum(int(row.get("cost_basis") or 0) for row in sales)
    total_realized = sum(int(row.get("realized_profit_loss") or 0) for row in sales)
    try:
        price_basis_date = latest_naver_trading_day().isoformat()
    except (OSError, ValueError, TypeError):
        price_basis_date = ""
    return {
        **state,
        "profile": profile,
        "equity_trend": recent_equity_trend(7, path),
        "price_updated_at": datetime.now().isoformat(timespec="seconds"),
        "price_basis_date": price_basis_date,
        "price_source": "네이버 금융 · 검증 실패 종목은 진입가 임시표시",
        "risk": risk,
        "strategy_version": strategy.get("version_id", "기본 전략"),
        "price_unavailable_tickers": unavailable,
        "market_up_ratio_pct": round(breadth * 100, 2) if breadth is not None else None,
        "market_exposure_limit_pct": market_limit,
        "market_mode": market_mode,
        "sales": sales,
        "sale_summary": {
            "count": len(sales),
            "realized_profit_loss": total_realized,
            "win_rate_pct": round(wins / len(sales) * 100, 2) if sales else 0.0,
            "return_pct": round(total_realized / total_cost * 100, 2) if total_cost else 0.0,
        },
    }


def remote_setup_page() -> str:
    content = ""
    for path in ("logs/cloudflared.err.log", "logs/cloudflared.out.log"):
        try:
            with open(path, encoding="utf-8", errors="replace") as file:
                content += file.read()
        except OSError:
            pass
    match = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", content)
    api_url = match.group(0) if match else ""
    token = os.environ.get("DASHBOARD_REMOTE_TOKEN", "")
    dashboard_url = "https://leewj1013.github.io/stock/?api=" + quote(api_url, safe="")
    return f"""<!doctype html><html lang=\"ko\"><meta charset=\"utf-8\"><title>원격 대시보드 연결</title>
<style>body{{font-family:Segoe UI,Malgun Gothic,sans-serif;max-width:680px;margin:48px auto;padding:0 20px}}input{{width:100%;padding:10px;box-sizing:border-box}}button,a{{display:inline-block;margin:12px 8px 0 0;padding:10px 14px}}.muted{{color:#666}}</style>
<h1>원격 대시보드 연결</h1><p>API 주소: <b>{html.escape(api_url or '터널 미실행')}</b></p>
<label for=\"token\">읽기 전용 접속 토큰</label><input id=\"token\" type=\"password\" readonly value={html.escape(json.dumps(token))}>
<button id=\"copy\" type=\"button\">토큰 복사</button><a href=\"{html.escape(dashboard_url)}\" target=\"_blank\" rel=\"noreferrer\">GitHub Pages 열기</a>
<p class=\"muted\" id=\"status\">토큰 복사 후 GitHub Pages의 토큰 입력란에 붙여넣으세요.</p>
<script>document.getElementById('copy').onclick=async()=>{{await navigator.clipboard.writeText(document.getElementById('token').value);document.getElementById('status').textContent='토큰을 복사했습니다.';}};</script></html>"""


# Legacy virtual-trader imports are the largest body this server accepts, and
# they are a few KB; anything past this is not a real dashboard request.
MAX_BODY_BYTES = 1_000_000


def read_request_body(handler: BaseHTTPRequestHandler) -> bytes:
    """Consume the declared request body, including for requests about to be
    rejected. Closing a socket that still holds unread request bytes makes
    Windows reset the connection instead of closing it, so the client sees
    ConnectionAbortedError (WinError 10053) rather than the 403/401 it was
    actually sent -- which is also what made the rejection test flaky."""
    try:
        length = int(handler.headers.get("Content-Length", "0") or 0)
    except ValueError:
        return b""
    if length <= 0:
        return b""
    return handler.rfile.read(min(length, MAX_BODY_BYTES))


class DashboardHandler(BaseHTTPRequestHandler):
    """Loopback-only dashboard and virtual-account write API."""

    def _security_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'")

    def _cors(self) -> None:
        # Same-origin access via http://127.0.0.1:PORT/ (open_dashboard.bat)
        # never involves CORS at all, so this handler historically sent no
        # CORS headers. Opening dashboard.html directly (file://) is
        # cross-origin with Origin: null, and browsers then withhold the
        # response from JS without this header -- the dashboard's trader
        # panel silently renders its empty initial state instead. HOST
        # already binds to loopback only, so this stays narrowly scoped to
        # file:// rather than reflecting arbitrary origins. This is read-only:
        # do_POST explicitly rejects Origin:null, so a downloaded HTML file
        # cannot mutate the virtual account.
        if self.headers.get("Origin", "") == "null":
            self.send_header("Access-Control-Allow-Origin", "null")
            self.send_header("Vary", "Origin")

    def _json(self, status: int, body: dict) -> None:
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._security_headers()
        self._cors()
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self) -> None:  # noqa: N802
        if not allowed_local_origin(self.headers.get("Origin", "")):
            self.send_error(403)
            return
        self.send_response(204)
        self._cors()
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/trader":
            profile = parse_qs(parsed.query).get("profile", ["aggressive"])[0]
            self._json(200, trader_payload(profile if profile in PROFILES else "aggressive"))
            return
        if path == "/us":
            payload = render_us().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._security_headers()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if path in {"/", "/dashboard"}:
            # The static dashboard.html (file:// / Pages) has no /us route, so the link is added only when served here.
            payload = render().replace("</header>", '<a href="/us" style="align-self:center;margin-left:auto;margin-right:16px;font-weight:600">미국 &rarr;</a></header>', 1).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._security_headers()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if path == "/remote-setup":
            payload = remote_setup_page().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self._security_headers()
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        self.send_error(404)

    def do_POST(self) -> None:  # noqa: N802
        try:
            raw_body = read_request_body(self)
            origin = self.headers.get("Origin", "")
            if not allowed_local_origin(origin):
                self._json(403, {"error": "허용되지 않은 요청 출처입니다."})
                return
            body = json.loads(raw_body or b"{}")
            path = urlparse(self.path).path
            profile = body.get("profile") if body.get("profile") in PROFILES else "aggressive"
            db_path = profile_db_path(profile)
            if path == "/api/trader/deposit":
                virtual_deposit(int(body.get("amount", 0)), path=db_path)
                self._json(200, trader_payload(profile))
                return
            if path == "/api/trader/buy":
                result = virtual_buy(recommendations(), path=db_path)
                self._json(200, {**trader_payload(profile), **{key: result[key] for key in ("spent", "bought", "executions")}})
                return
            if path == "/api/trader/import":
                imported = import_legacy_virtual_trader(body, path=db_path)
                self._json(200, {**trader_payload(profile), "imported": imported})
                return
            self.send_error(404)
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self._json(400, {"error": str(error)})
        except Exception as error:
            write_error_log(error)
            self._json(500, {"error": "가상 트레이더 처리 중 오류가 발생했습니다."})

    def log_message(self, format: str, *args: object) -> None:
        return


class RemoteReadOnlyHandler(BaseHTTPRequestHandler):
    """The only handler ever exposed through the Cloudflare tunnel.

    Serves a single read-only, token-gated route and nothing else -- no
    dashboard HTML, no /remote-setup (which would leak the token itself), no
    write routes. Anyone who finds the tunnel URL still needs a valid
    DASHBOARD_REMOTE_TOKEN to get anything back.
    """

    def _cors(self) -> None:
        origin = allowed_origin(self.headers.get("Origin", ""))
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")

    def _json(self, status: int, body: dict) -> None:
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self._cors()
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self) -> None:  # noqa: N802
        if not allowed_origin(self.headers.get("Origin", "")):
            self.send_error(403)
            return
        self.send_response(204)
        self._cors()
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/api/trader":
            self.send_error(404)
            return
        if not allowed_origin(self.headers.get("Origin", "")) or not valid_remote_token(self.headers.get("Authorization", "")):
            self._json(401, {"error": "원격 대시보드 인증이 필요합니다."})
            return
        profile = parse_qs(parsed.query).get("profile", ["aggressive"])[0]
        self._json(200, trader_payload(profile if profile in PROFILES else "aggressive"))

    def do_POST(self) -> None:  # noqa: N802
        read_request_body(self)
        self._json(403, {"error": "원격에서는 조회만 가능합니다."})

    def log_message(self, format: str, *args: object) -> None:
        return


def main() -> None:
    global PORT, REMOTE_PORT, REMOTE_ORIGIN
    load_env()
    PORT = int(os.environ.get("DASHBOARD_PORT", str(PORT)))
    REMOTE_PORT = int(os.environ.get("DASHBOARD_REMOTE_PORT", str(REMOTE_PORT)))
    REMOTE_ORIGIN = os.environ.get("DASHBOARD_REMOTE_ORIGIN", REMOTE_ORIGIN).rstrip("/")
    remote_server = ThreadingHTTPServer((HOST, REMOTE_PORT), RemoteReadOnlyHandler)
    threading.Thread(target=remote_server.serve_forever, daemon=True).start()
    server = ThreadingHTTPServer((HOST, PORT), DashboardHandler)
    print(f"http://{HOST}:{PORT}/", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
