from __future__ import annotations

from .data_store import DB_PATH

# Sizing and exit thresholds differ per profile, and (since the profile
# scoring feature) so does which candidates get picked in the first place:
# scoring_weights re-ranks the shared, already quality-filtered candidate
# pool (see app.py:select_for_profile) -- it never loosens the existing
# safety filters. None means "use the existing env-driven default", so the
# aggressive profile's behavior is unchanged from before profiles existed.
PROFILES = {
    "aggressive": {
        "db_path": DB_PATH,
        "sell_alerts_log": "logs/sell_alerts.csv",
        "notify": True,
        "sector_cap_pct": None,
        "exposure_limit_pct": None,
        "min_position_pct": None,
        "max_position_pct": None,
        "sell_policy": None,
        # 성장성/모멘텀 중심 -- 안정성/배당 비중은 낮춘다.
        # 2026-09-19: 뉴스 가중치 0 -- 키워드 감성은 어느 기간에서도 수익률을
        # 예측하지 못했다. 나머지는 기존 비율대로 재분배. news_score 기록은 유지.
        "scoring_weights": {"profitability": 0.222, "growth": 0.333, "stability": 0.111, "dividend": 0.056, "momentum": 0.278, "news": 0.0},
        "max_volatility_atr_pct": None,
        "max_holdings": 7,
        # 백테스트에서 확인: 상승/하락 추세에선 baseline보다 낫지만 횡보장에서
        # 유독 약함 (모멘텀이 자꾸 반전당함). 가중치는 그대로 두고 횡보장에서만
        # 노출 한도를 절반으로 줄여 그 약점만 겨냥한다.
        "regime_exposure_multiplier": {"sideways": 0.5},
    },
    "neutral": {
        "db_path": "data/stock_alarm_neutral.db",
        "sell_alerts_log": "logs/sell_alerts_neutral.csv",
        "notify": False,
        "sector_cap_pct": 30.0,
        "exposure_limit_pct": 50.0,
        "min_position_pct": 10.0,
        "max_position_pct": 20.0,
        "sell_policy": {"stop_loss_pct": 3.0, "take_profit_1_pct": 7.0, "take_profit_2_pct": 14.0},
        # 안정성/수익성 중심 -- 모멘텀 비중은 낮춘다.
        # 2026-09-19: 뉴스 가중치 0 -- 키워드 감성은 어느 기간에서도 수익률을
        # 예측하지 못했다. 나머지는 기존 비율대로 재분배. news_score 기록은 유지.
        "scoring_weights": {"profitability": 0.263, "growth": 0.211, "stability": 0.316, "dividend": 0.105, "momentum": 0.105, "news": 0.0},
        "max_volatility_atr_pct": 6.0,
        "max_holdings": 10,
        "regime_exposure_multiplier": {},
    },
}

# Forward A/B experiment: two comparison-only accounts that start together
# with the same balance and buy exactly what "aggressive" picks, so the only
# difference between them is the exit/risk-release rule. exp_candidate runs
# the best backtested variant -- no take-profit when the previous session was
# a bull regime, and a drawdown halt that re-opens buys at 30% size after 20
# trading days instead of locking the account in cash. comparison_only keeps
# them out of weight learning/validation.
PROFILES["exp_control"] = {
    **PROFILES["aggressive"],
    "db_path": "data/stock_alarm_exp_control.db",
    "sell_alerts_log": "logs/sell_alerts_exp_control.csv",
    "notify": False,
    "comparison_only": True,
}
PROFILES["exp_candidate"] = {
    **PROFILES["exp_control"],
    "db_path": "data/stock_alarm_exp_candidate.db",
    "sell_alerts_log": "logs/sell_alerts_exp_candidate.csv",
    "sell_policy": {"disable_take_profit_in_regimes": ["bull"]},
    "risk_release": {"mode": "cooldown", "cooldown_days": 20, "reentry_scale": 0.3},
}

# Stock/cash style comparison. The percentage is a ceiling; market breadth,
# eligible recommendations and risk halts can leave more cash than the target.
PROFILES["exp_cash_neutral"] = {
    **PROFILES["neutral"],
    "db_path": "data/stock_alarm_exp_cash_neutral.db",
    "sell_alerts_log": "logs/sell_alerts_exp_cash_neutral.csv",
    "notify": False,
    "comparison_only": True,
    "exposure_limit_pct": 60.0,
}
PROFILES["exp_stock_aggressive"] = {
    **PROFILES["aggressive"],
    "db_path": "data/stock_alarm_exp_stock_aggressive.db",
    "sell_alerts_log": "logs/sell_alerts_exp_stock_aggressive.csv",
    "notify": False,
    "comparison_only": True,
    "exposure_limit_pct": 100.0,
    "regime_exposure_multiplier": {},
}

CATEGORY_VALUE_KEYS = {
    "profitability": "profitability_score",
    "growth": "growth_score",
    "stability": "stability_score",
    "dividend": "dividend_score",
    "momentum": "momentum_score",
    "news": "news_category_score",
}
